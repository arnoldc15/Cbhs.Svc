﻿using System;
using System.Net.Http;
using System.Threading.Tasks;
using Cbhs.Svc.OshcReceipt.Application.Interfaces.Infrastructure;
using Microsoft.Extensions.Configuration;

namespace Cbhs.Svc.OshcReceipt.Infrastructure
{
    public class RebateService : IRebateService
    {
        private readonly HttpClient _client;
        private readonly IConfiguration _config;

        public RebateService(IConfiguration config, HttpClient client)
        {
            _config = config;
            _client = client;
        }


        public async Task<decimal> GetRebatePercentage(int memberId)
        {
            //string endPoint = _config["GetRebatePercentage"];
            var resp1 = await _client.SendAsync(new HttpRequestMessage(HttpMethod.Get,
                new Uri("http://api.icndb.com/jokes/random")));

            return (await resp1.Content.ReadAsStringAsync()).Length;
        }
    }
}