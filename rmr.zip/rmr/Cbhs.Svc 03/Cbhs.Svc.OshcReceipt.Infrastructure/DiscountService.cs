﻿using System;
using System.Net.Http;
using System.Threading.Tasks;
using Cbhs.Svc.OshcReceipt.Application.Interfaces.Infrastructure;
using Microsoft.Extensions.Configuration;

namespace Cbhs.Svc.OshcReceipt.Infrastructure
{
    public class DiscountService : IDiscountService
    {
        private readonly HttpClient _client;
        private readonly IConfiguration _config;

        public DiscountService(IConfiguration config, HttpClient client)
        {
            _config = config;
            _client = client;
        }

        public async Task<decimal> GetDiscountPercentage(int memberId)
        {
            //string endPoint = _config["GetRebatePercentage"];
            var resp1 = await _client.SendAsync(new HttpRequestMessage(HttpMethod.Get,
                new Uri("http://api.icndb.com/jokes/random")));

            return (await resp1.Content.ReadAsStringAsync()).Length;
        }
    }
}