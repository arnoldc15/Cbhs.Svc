﻿using Cbhs.Svc.OshcReceipt.Domain.Entities.ReceiptAggregate;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Cbhs.Svc.OshcReceipt.Persistence.Configurations
{
    public class ReceiptLineConfiguration : IEntityTypeConfiguration<ReceiptLine>
    {
        public void Configure(EntityTypeBuilder<ReceiptLine> builder)
        {
            builder.ToTable("ReceiptLine");
            builder.HasKey(e => e.ReceiptLineId);
            builder.Property(e => e.ReceiptId);
            builder.Property(e => e.StartDate).IsRequired();
            builder.Property(e => e.EndDate).IsRequired();
            builder.Property(e => e.ReceiptCost).IsRequired();
            builder.Property(e => e.RebateCost).IsRequired();
            builder.Property(e => e.DiscountCost).IsRequired();
            builder.HasOne(r => r.Receipt)
                .WithMany(l => l.ReceiptLines)
                .HasForeignKey(r => r.ReceiptId);
        }
    }
}