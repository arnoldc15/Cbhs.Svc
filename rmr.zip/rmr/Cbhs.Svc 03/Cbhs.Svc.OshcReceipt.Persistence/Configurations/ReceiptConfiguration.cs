﻿using Cbhs.Svc.OshcReceipt.Domain.Entities.ReceiptAggregate;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Cbhs.Svc.OshcReceipt.Persistence.Configurations
{
    public class ReceiptConfiguration : IEntityTypeConfiguration<Receipt>
    {
        public void Configure(EntityTypeBuilder<Receipt> builder)
        {
            builder.ToTable("ReceiptSummary");
            builder.HasKey(e => e.ReceiptId);
            //builder.HasMany(l => l.ReceiptLines)
            //    .WithOne(r => r.Receipt);
            builder.Property(e => e.MembershipId).IsRequired();
            builder.Property(e => e.OldPaidToDate).IsRequired();
            builder.Property(e => e.NewPaidToDate).IsRequired();
            builder.Property(e => e.ReceiptCost).IsRequired();
            builder.Property(e => e.RebateCost).IsRequired();
            builder.Property(e => e.DiscountCost).IsRequired();
        }
    }
}