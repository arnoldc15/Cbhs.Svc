﻿using Cbhs.Svc.OshcReceipt.Application.Interfaces;
using Cbhs.Svc.OshcReceipt.Domain.Entities.ReceiptAggregate;
using Microsoft.EntityFrameworkCore;

namespace Cbhs.Svc.OshcReceipt.Persistence
{
    public class ReceiptDbContext : DbContext, IReceiptDbContext
    {
        public ReceiptDbContext(DbContextOptions<ReceiptDbContext> options)
            : base(options)
        {
        }

        public DbSet<Receipt> Receipts { get; set; }
        public DbSet<ReceiptLine> ReceiptLines { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfigurationsFromAssembly(typeof(ReceiptDbContext).Assembly);
        }
    }
}