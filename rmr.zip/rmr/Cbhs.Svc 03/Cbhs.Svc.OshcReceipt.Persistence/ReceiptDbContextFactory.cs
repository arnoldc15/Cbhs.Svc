﻿using Microsoft.EntityFrameworkCore;

namespace Cbhs.Svc.OshcReceipt.Persistence
{
    public class ReceiptDbContextFactory : DesignTimeDbContextFactoryBase<ReceiptDbContext>
    {
        protected override ReceiptDbContext CreateNewInstance(DbContextOptions<ReceiptDbContext> options)
        {
            return new ReceiptDbContext(options);
        }
    }
}