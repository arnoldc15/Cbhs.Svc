﻿using System;
using System.Linq.Expressions;
using Cbhs.Svc.OshcReceipt.Domain.Entities.ReceiptAggregate;


namespace Cbhs.Svc.OshcReceipt.Application.Queries.SharedModels
{
    public class ReceiptLineModel
    {
        public int ReceiptLineId { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public decimal ReceiptCost { get; set; }
        public decimal RebateCost { get; set; }
        public decimal DiscountCost { get; set; }

        public static Expression<Func<ReceiptLine, ReceiptLineModel>> Projection
        {
            get
            {
                return domain => new ReceiptLineModel
                {
                    ReceiptLineId = domain.ReceiptLineId,
                    StartDate = domain.StartDate,
                    EndDate = domain.EndDate,
                    ReceiptCost = domain.ReceiptCost,
                    RebateCost = domain.RebateCost,
                    DiscountCost = domain.DiscountCost

                };
            }
        }
    }
}