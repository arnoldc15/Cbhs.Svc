﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using Cbhs.Svc.OshcReceipt.Domain.Entities.ReceiptAggregate;

namespace Cbhs.Svc.OshcReceipt.Application.Queries.SharedModels
{
    public class ReceiptViewModel
    {

        public int ReceiptId { get; set; }
        public int MembershipId { get; set; }
        public DateTime OldPaidToDate { get; set; }
        public DateTime NewPaidToDate { get; set; }
        public decimal ReceiptCost { get; set; }
        public decimal RebateCost { get; set; }
        public decimal DiscountCost { get; set; }
        public ICollection<ReceiptLineModel> ReceiptLines { get; set; }

        public static Expression<Func<Receipt, ReceiptViewModel>> Projection
        {
            get
            {
                return domain => new ReceiptViewModel
                {
                    ReceiptId = domain.ReceiptId,
                    MembershipId = domain.MembershipId,
                    OldPaidToDate = domain.OldPaidToDate,
                    NewPaidToDate = domain.NewPaidToDate,
                    ReceiptCost = domain.ReceiptCost,
                    RebateCost = domain.RebateCost,
                    DiscountCost = domain.DiscountCost,
                    ReceiptLines = domain.ReceiptLines.AsQueryable()
                        .Select(ReceiptLineModel.Projection).ToList()
                };
            }
        }

        public static ReceiptViewModel Create(Receipt receipt)
        {
            return Projection.Compile().Invoke(receipt);
        }


    }
}