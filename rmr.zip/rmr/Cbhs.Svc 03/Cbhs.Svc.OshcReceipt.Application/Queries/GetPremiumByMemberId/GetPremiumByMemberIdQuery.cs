﻿using System;
using System.Threading;
using System.Threading.Tasks;
using Cbhs.Svc.OshcReceipt.Application.Interfaces;
using Cbhs.Svc.OshcReceipt.Application.Interfaces.Infrastructure;
using Cbhs.Svc.OshcReceipt.Domain.Entities.ReceiptAggregate;
using MediatR;

namespace Cbhs.Svc.OshcReceipt.Application.Queries.GetPremiumByMemberId
{
    public class GetPremiumByMemberIdQuery : IRequest<decimal>
    {
        public int memberId { get; set; }
    }


    public class GetPremiumByMemberIdHandler : IRequestHandler<GetPremiumByMemberIdQuery, decimal>
    {
        private readonly IReceiptDbContext _context;
        private readonly IDiscountService _discountService;
        private readonly IProductService _productService;
        private readonly IRebateService _rebateService;

        public GetPremiumByMemberIdHandler(IReceiptDbContext context,
            IRebateService rebateService, IProductService productService, IDiscountService discountService)
        {
            _context = context;
            _rebateService = rebateService;
            _productService = productService;
            _discountService = discountService;
        }

        public async Task<decimal> Handle(GetPremiumByMemberIdQuery request, CancellationToken cancellationToken)
        {
            var rebateTask = _rebateService.GetRebatePercentage(request.memberId);
            var productFeeTask = _productService.GetProductFee(request.memberId);
            var discountTask = _discountService.GetDiscountPercentage(request.memberId);

            await Task.WhenAll(rebateTask, productFeeTask, discountTask);

            var rebate = await rebateTask;
            var productFee = await productFeeTask;
            var discount = await discountTask;

            var receipt = new Receipt(rebate, discount,
                productFee, DateTime.Now, DateTime.Now.AddDays(1));

            return receipt.ReceiptCost;
        }
    }
}