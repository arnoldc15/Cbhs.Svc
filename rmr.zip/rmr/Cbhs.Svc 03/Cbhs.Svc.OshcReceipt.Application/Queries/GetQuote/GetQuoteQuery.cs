﻿using System;
using System.Threading;
using System.Threading.Tasks;
using Cbhs.Svc.OshcReceipt.Application.Interfaces;
using Cbhs.Svc.OshcReceipt.Domain.Entities.ReceiptAggregate;
using MediatR;

namespace Cbhs.Svc.OshcReceipt.Application.Queries.GetQuote
{
    public class GetQuoteQuery : IRequest<QuoteViewModel>
    {
        public decimal RebatePercentage { get; set; }
        public decimal DiscountPercentage { get; set; }
        public decimal ProductCost { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
    }


    public class GetQuoteQueryHandler : IRequestHandler<GetQuoteQuery, QuoteViewModel>
    {
        private readonly IReceiptDbContext _context;

        public GetQuoteQueryHandler(IReceiptDbContext context)
        {
            _context = context;
        }

        public async Task<QuoteViewModel> Handle(GetQuoteQuery request, CancellationToken cancellationToken)
        {
            var quote = new Receipt(request.RebatePercentage, request.DiscountPercentage,
                request.ProductCost, request.StartDate, request.EndDate);

            //to create a task extension for linq expression
            await Task.Delay(1);

            return QuoteViewModel.Create(quote);
        }
    }
}