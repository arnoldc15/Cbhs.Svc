﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using Cbhs.Svc.OshcReceipt.Application.Queries.SharedModels;
using Cbhs.Svc.OshcReceipt.Domain.Entities.ReceiptAggregate;

namespace Cbhs.Svc.OshcReceipt.Application.Queries.GetQuote
{
    public class QuoteViewModel
    {
        public DateTime OldPaidToDate { get; set; }
        public DateTime NewPaidToDate { get; set; }
        public decimal ReceiptCost { get; set; }
        public decimal RebateCost { get; set; }
        public decimal DiscountCost { get; set; }
        public ICollection<ReceiptLineModel> ReceiptLines { get; set; }


        public static Expression<Func<Receipt, QuoteViewModel>> Projection
        {
            get
            {
                return domain => new QuoteViewModel
                {
                    OldPaidToDate = domain.OldPaidToDate,
                    NewPaidToDate = domain.NewPaidToDate,
                    ReceiptCost = domain.ReceiptCost,
                    RebateCost = domain.RebateCost,
                    DiscountCost = domain.DiscountCost,
                    ReceiptLines = domain.ReceiptLines.AsQueryable().Select(ReceiptLineModel.Projection).ToList()
                };
            }
        }

        public static QuoteViewModel Create(Receipt receipt)
        {
            return Projection.Compile().Invoke(receipt);
        }
    }
}