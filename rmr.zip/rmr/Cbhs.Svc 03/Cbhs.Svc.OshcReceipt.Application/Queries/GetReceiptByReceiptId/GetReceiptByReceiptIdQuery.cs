﻿using System.Threading;
using System.Threading.Tasks;
using Cbhs.Svc.OshcReceipt.Application.Interfaces;
using Cbhs.Svc.OshcReceipt.Application.Queries.SharedModels;
using MediatR;
using Microsoft.EntityFrameworkCore;

namespace Cbhs.Svc.OshcReceipt.Application.Queries.GetReceiptByReceiptId
{
    public class GetReceiptByReceiptIdQuery : IRequest<ReceiptViewModel>
    {
        public int ReceiptId { get; set; }
    }

    public class GetReceiptByReceiptIdQueryHandler : IRequestHandler<GetReceiptByReceiptIdQuery, ReceiptViewModel>
    {
        private readonly IReceiptDbContext _context;

        public GetReceiptByReceiptIdQueryHandler(IReceiptDbContext context)
        {
            _context = context;
        }

        public async Task<ReceiptViewModel> Handle(GetReceiptByReceiptIdQuery request,
            CancellationToken cancellationToken)
        {
            //careful with n+1 issue
            var receipt = await _context.Receipts.Include(r=> r.ReceiptLines)
                .FirstAsync(r => r.ReceiptId == request.ReceiptId, cancellationToken: cancellationToken);

            return ReceiptViewModel.Create(receipt);
        }
    }
}