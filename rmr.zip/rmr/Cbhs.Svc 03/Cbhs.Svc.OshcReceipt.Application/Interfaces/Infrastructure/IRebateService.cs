﻿using System.Threading.Tasks;

namespace Cbhs.Svc.OshcReceipt.Application.Interfaces.Infrastructure
{
    public interface IRebateService
    {
        Task<decimal> GetRebatePercentage(int memberId);
    }
}