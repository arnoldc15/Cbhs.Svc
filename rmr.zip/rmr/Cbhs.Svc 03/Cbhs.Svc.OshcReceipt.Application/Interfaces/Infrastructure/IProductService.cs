﻿using System.Threading.Tasks;

namespace Cbhs.Svc.OshcReceipt.Application.Interfaces.Infrastructure
{
    public interface IProductService
    {
        Task<decimal> GetProductFee(int memberId);
    }
}