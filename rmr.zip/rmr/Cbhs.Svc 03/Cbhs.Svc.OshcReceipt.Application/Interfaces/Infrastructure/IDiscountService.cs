﻿using System.Threading.Tasks;

namespace Cbhs.Svc.OshcReceipt.Application.Interfaces.Infrastructure
{
    public interface IDiscountService
    {
        Task<decimal> GetDiscountPercentage(int memberId);
    }
}