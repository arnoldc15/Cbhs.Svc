﻿using Cbhs.Svc.OshcReceipt.Domain.Entities.ReceiptAggregate;
using Microsoft.EntityFrameworkCore;

namespace Cbhs.Svc.OshcReceipt.Application.Interfaces
{
    public interface IReceiptDbContext
    {
        DbSet<Receipt> Receipts { get; set; }
        DbSet<ReceiptLine> ReceiptLines { get; set; }
    }
}