﻿using System;

namespace Cbhs.Svc.OshcReceipt.Domain.Entities.ReceiptAggregate
{
    public class ReceiptLine
    {
        private ReceiptLine()
        {
        }

        public ReceiptLine(int lineId, DateTime startDate,
            DateTime endDate, decimal productCost, decimal rebatePercentage, decimal discountPercentage)
        {
            StartDate = startDate;
            EndDate = endDate;
            RebateCost = CalculateRebateAmount(rebatePercentage, productCost);
            DiscountCost = CalculateDiscountAmount(discountPercentage, productCost);
            ReceiptCost = CalculateReceiptAmount(RebateCost, DiscountCost, productCost);
        }

        public int ReceiptLineId { get; private set; }
        public int ReceiptId { get; private set; }
        public DateTime StartDate { get; private set; }
        public DateTime EndDate { get; private set; }
        public decimal ReceiptCost { get; private set; }
        public decimal RebateCost { get; private set; }
        public decimal DiscountCost { get; private set; }
        public Receipt Receipt { get; private set; }

        public decimal CalculateRebateAmount(decimal rebatePercentage, decimal productCost)
        {
            return productCost * rebatePercentage;
        }

        public decimal CalculateReceiptAmount(decimal rebateCost, decimal discountAmount, decimal productCost)
        {
            return productCost - rebateCost - discountAmount;
        }

        public decimal CalculateDiscountAmount(decimal rebateCost, decimal productCost)
        {
            return productCost - rebateCost;
        }
    }
}