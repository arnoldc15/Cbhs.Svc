﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Cbhs.Svc.OshcReceipt.Domain.Entities.ReceiptAggregate
{
    public class Receipt
    {
        private Receipt()
        {
            ReceiptLines = new HashSet<ReceiptLine>();
        }


        public Receipt(decimal rebatePercentage, decimal discountPercentage, decimal productCost, DateTime startDate,
            DateTime endDate)
        {
            OldPaidToDate = startDate;
            NewPaidToDate = endDate;
            ReceiptLines = CreateReceiptlines(rebatePercentage, discountPercentage, productCost, startDate, endDate);
            ReceiptCost = CalculateReceiptCost(ReceiptLines);
            RebateCost = CalculateRebateCost(ReceiptLines);
            DiscountCost = CalculateDiscountCost(ReceiptLines);
        }

        public int ReceiptId { get; private set; }
        public int MembershipId { get; private set; }
        public DateTime OldPaidToDate { get; private set; }
        public DateTime NewPaidToDate { get; private set; }
        public decimal ReceiptCost { get; private set; }
        public decimal RebateCost { get; private set; }
        public decimal DiscountCost { get; private set; }
        public ICollection<ReceiptLine> ReceiptLines { get; private set; }

        public decimal CalculateReceiptCost(ICollection<ReceiptLine> receiptlines)
        {
            return receiptlines.Sum(x => x.ReceiptCost);
        }

        public decimal CalculateRebateCost(ICollection<ReceiptLine> receiptlines)
        {
            return receiptlines.Sum(x => x.RebateCost);
        }

        public decimal CalculateDiscountCost(ICollection<ReceiptLine> receiptlines)
        {
            return receiptlines.Sum(x => x.DiscountCost);
        }

        private ICollection<ReceiptLine> CreateReceiptlines(decimal rebatePercentage, decimal discountPercentage,
            decimal productCost, DateTime startDate, DateTime endDate)
        {
            var receiptLine = new List<ReceiptLine>();

            //line 1
            receiptLine.Add(new ReceiptLine(1, startDate, startDate.AddDays(7), productCost / 2, rebatePercentage,
                discountPercentage));
            //line 2
            receiptLine.Add(new ReceiptLine(2, startDate.AddDays(7), endDate, productCost / 2, rebatePercentage,
                discountPercentage));

            return receiptLine;
        }
    }
}